import 'package:flutter_test/flutter_test.dart';
import 'package:root_x/core/modules.dart';

void main() {
  test('module ids are unique', () {
    final ids = toolModules.map((m) => m.id).toList();
    expect(ids.toSet().length, ids.length);
  });

  test('every module has a valid stage', () {
    for (final m in toolModules) {
      expect(m.stage, inInclusiveRange(1, 8), reason: m.id);
    }
  });

  test('dashboard grid references existing modules', () {
    expect(dashboardModules.length, dashboardModuleIds.length);
  });

  test('planned modules do not claim a tab', () {
    for (final m in toolModules) {
      if (m.status == ModuleStatus.planned) {
        expect(m.tabIndex, isNull, reason: m.id);
      }
    }
  });
}
