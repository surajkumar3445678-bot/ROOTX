# ROOT X – ULTIMATE PRO

*One APK. Complete Android Control.*

Flutter + Kotlin Android toolkit. Built in stages; each module shows its real
implementation status in the app (Tools tab).

## Current status: Stage 1

| Area | Status |
|---|---|
| Architecture, theme (dark/light, 5 accents), logo, adaptive icon | Ready |
| Dashboard (real device data via Kotlin) | Ready |
| Global module search | Ready |
| Apps list (launchable apps) | Ready |
| System Monitor (RAM, storage, battery, device info) | Partial (CPU freq/GPU/temps in Stage 4) |
| Root detection | Partial: only checks for a `su` binary, access is not verified |
| File Manager, APK Studio, Permissions, Root/Shizuku/ADB, Gaming, Dev tools, Backup, Automation, Plugins, Floating Toolbox, Web Server | Planned (Stages 2–7) |

Not yet included: integration tests (Stage 8), PNG logo exports (the launcher
icon is vector based and works on API 26+).

## Build (GitHub Actions)

1. Create a GitHub repo and upload this project (or upload the ZIP itself).
2. Push to `main`, or run **Actions → Build ROOT X APK → Run workflow**.
3. Download `ROOT-X-APKs` from the run's artifacts (debug and release APK).

The workflow finds `pubspec.yaml` anywhere in the repo (or inside an uploaded
ZIP), creates missing Gradle files with `flutter create`, keeps our own
`AndroidManifest.xml` and Kotlin code, runs analyze + tests, then builds.
On failure the `.log` files are uploaded as `build-logs`.

The release APK is signed with the debug key unless you add your own keystore.

## Build locally

```
flutter create --platforms=android --org com.rootx --project-name root_x .   # only if android/ is missing Gradle files; do not overwrite our files
flutter pub get
flutter test
flutter build apk --debug
```

## Install

Copy the APK to your phone, allow "Install unknown apps" for your file manager
and open it. Requires Android 8.0 (API 26) or newer.

## Structure

See `docs/ARCHITECTURE.md`.
