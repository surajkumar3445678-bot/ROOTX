import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/modules.dart';
import '../../core/providers.dart';
import '../../core/widgets/status_chip.dart';

/// Opens a module: jumps to its tab if it has one, otherwise shows its
/// honest implementation status.
void openModule(BuildContext context, WidgetRef ref, ToolModule module) {
  final tab = module.tabIndex;
  if (tab != null) {
    ref.read(navIndexProvider.notifier).state = tab;
    return;
  }
  showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    builder: (ctx) => Padding(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 28),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(module.icon, color: Theme.of(ctx).colorScheme.primary),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  module.title,
                  style: Theme.of(ctx).textTheme.titleLarge,
                ),
              ),
              StatusChip(status: module.status),
            ],
          ),
          const SizedBox(height: 8),
          Text(module.subtitle),
          const SizedBox(height: 12),
          Text(
            'Planned for Stage ${module.stage}. This module has no working '
            'features in this build yet.',
            style: Theme.of(ctx).textTheme.bodyMedium,
          ),
        ],
      ),
    ),
  );
}
