import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/providers.dart';

class AppsScreen extends ConsumerStatefulWidget {
  const AppsScreen({super.key});

  @override
  ConsumerState<AppsScreen> createState() => _AppsScreenState();
}

class _AppsScreenState extends ConsumerState<AppsScreen> {
  String _query = '';
  bool _showSystem = false;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final apps = ref.watch(appsProvider);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Apps',
                  style: theme.textTheme.headlineSmall
                      ?.copyWith(fontWeight: FontWeight.w700)),
              const SizedBox(height: 4),
              Text('Launchable apps installed on this device.',
                  style: theme.textTheme.bodyMedium),
              const SizedBox(height: 12),
              TextField(
                decoration: const InputDecoration(
                  prefixIcon: Icon(Icons.search_rounded),
                  hintText: 'Search by name or package',
                  border: OutlineInputBorder(),
                  isDense: true,
                ),
                onChanged: (v) => setState(() => _query = v.trim().toLowerCase()),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Show system apps'),
                value: _showSystem,
                onChanged: (v) => setState(() => _showSystem = v),
              ),
            ],
          ),
        ),
        Expanded(
          child: apps.when(
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (e, _) => Center(child: Text('Could not load apps: $e')),
            data: (list) {
              final filtered = list.where((a) {
                if (!_showSystem && a.isSystem) return false;
                if (_query.isEmpty) return true;
                return a.name.toLowerCase().contains(_query) ||
                    a.packageName.toLowerCase().contains(_query);
              }).toList();
              if (list.isEmpty) {
                return const Center(
                  child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Text(
                      'No app data available. Run the app on an Android device.',
                      textAlign: TextAlign.center,
                    ),
                  ),
                );
              }
              if (filtered.isEmpty) {
                return const Center(child: Text('No apps match.'));
              }
              return ListView.builder(
                itemCount: filtered.length,
                itemBuilder: (context, i) {
                  final a = filtered[i];
                  final initial =
                      a.name.isEmpty ? '?' : a.name.substring(0, 1).toUpperCase();
                  return ListTile(
                    leading: CircleAvatar(child: Text(initial)),
                    title: Text(a.name),
                    subtitle: Text(
                      a.version.isEmpty
                          ? a.packageName
                          : '${a.packageName} · v${a.version}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  );
                },
              );
            },
          ),
        ),
      ],
    );
  }
}
