# Architecture

- `lib/core` – theme, settings, module registry, platform channel, shared widgets.
- `lib/features/<module>` – one folder per feature. Later stages split each
  into `presentation / domain / data`.
- `android/app/src/main/kotlin` – native layer, exposed via MethodChannel
  `rootx/system` (device info, launchable apps).
- State: Riverpod. Preferences: shared_preferences. SQLite arrives with Stage 6.

## Permission tiers
1. Normal (SAF / scoped storage, official settings shortcuts)
2. Shizuku / ADB (Stage 3)
3. Root (Stage 4) – always shown with real status, never faked.

## Stages
1 Foundation · 2 Files + APK Studio · 3 Permissions/Shizuku/ADB · 4 Root +
Monitor · 5 Gaming + Dev tools · 6 Backup/Security/Automation · 7 Plugins,
Floating Toolbox, Web Server · 8 Tests, compatibility, release.
