import 'package:flutter/services.dart';

/// Real device information read by the Kotlin layer (MainActivity).
class DeviceInfo {
  const DeviceInfo({
    required this.androidVersion,
    required this.sdkInt,
    required this.manufacturer,
    required this.model,
    required this.buildNumber,
    required this.hardware,
    required this.abi,
    required this.cores,
    required this.ramTotal,
    required this.ramAvail,
    required this.storageTotal,
    required this.storageFree,
    required this.batteryPct,
    required this.batteryTempC,
    required this.charging,
    required this.suBinaryFound,
    required this.screenWidth,
    required this.screenHeight,
    required this.refreshRate,
  });

  final String androidVersion;
  final int sdkInt;
  final String manufacturer;
  final String model;
  final String buildNumber;
  final String hardware;
  final String abi;
  final int cores;
  final int ramTotal;
  final int ramAvail;
  final int storageTotal;
  final int storageFree;
  final int batteryPct;
  final double? batteryTempC;
  final bool charging;
  final bool suBinaryFound;
  final int screenWidth;
  final int screenHeight;
  final double refreshRate;

  double get ramUsedFraction =>
      ramTotal > 0 ? (ramTotal - ramAvail) / ramTotal : 0;

  double get storageUsedFraction =>
      storageTotal > 0 ? (storageTotal - storageFree) / storageTotal : 0;

  factory DeviceInfo.fromMap(Map<dynamic, dynamic> m) {
    int i(String k) => (m[k] as num?)?.toInt() ?? 0;
    String s(String k) => (m[k] as String?) ?? '';
    return DeviceInfo(
      androidVersion: s('androidVersion'),
      sdkInt: i('sdkInt'),
      manufacturer: s('manufacturer'),
      model: s('model'),
      buildNumber: s('buildNumber'),
      hardware: s('hardware'),
      abi: s('abi'),
      cores: i('cores'),
      ramTotal: i('ramTotal'),
      ramAvail: i('ramAvail'),
      storageTotal: i('storageTotal'),
      storageFree: i('storageFree'),
      batteryPct: (m['batteryPct'] as num?)?.toInt() ?? -1,
      batteryTempC: (m['batteryTempC'] as num?)?.toDouble(),
      charging: (m['charging'] as bool?) ?? false,
      suBinaryFound: (m['suBinaryFound'] as bool?) ?? false,
      screenWidth: i('screenWidth'),
      screenHeight: i('screenHeight'),
      refreshRate: (m['refreshRate'] as num?)?.toDouble() ?? 0,
    );
  }
}

class AppEntry {
  const AppEntry({
    required this.name,
    required this.packageName,
    required this.version,
    required this.isSystem,
  });

  final String name;
  final String packageName;
  final String version;
  final bool isSystem;

  factory AppEntry.fromMap(Map<dynamic, dynamic> m) => AppEntry(
        name: (m['name'] as String?) ?? '',
        packageName: (m['package'] as String?) ?? '',
        version: (m['version'] as String?) ?? '',
        isSystem: (m['system'] as bool?) ?? false,
      );
}

class SystemChannel {
  const SystemChannel();

  static const MethodChannel _channel = MethodChannel('rootx/system');

  /// Returns null when the native side is unavailable (e.g. not on Android).
  Future<DeviceInfo?> deviceInfo() async {
    try {
      final m = await _channel
          .invokeMethod<Map<dynamic, dynamic>>('getDeviceInfo');
      return m == null ? null : DeviceInfo.fromMap(m);
    } on PlatformException {
      return null;
    } on MissingPluginException {
      return null;
    }
  }

  Future<List<AppEntry>> launchableApps() async {
    try {
      final list = await _channel
          .invokeListMethod<Map<dynamic, dynamic>>('getLaunchableApps');
      return (list ?? const <Map<dynamic, dynamic>>[])
          .map(AppEntry.fromMap)
          .toList();
    } on PlatformException {
      return const [];
    } on MissingPluginException {
      return const [];
    }
  }
}
