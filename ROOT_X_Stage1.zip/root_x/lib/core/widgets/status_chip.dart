import 'package:flutter/material.dart';

import '../modules.dart';
import '../theme/app_colors.dart';

class StatusChip extends StatelessWidget {
  const StatusChip({super.key, required this.status});

  final ModuleStatus status;

  @override
  Widget build(BuildContext context) {
    final color = switch (status) {
      ModuleStatus.ready => const Color(0xFF00D68F),
      ModuleStatus.partial => AppColors.cyan,
      ModuleStatus.planned => Colors.grey,
    };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: color.withAlpha(40),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        status.label,
        style: TextStyle(
          color: color,
          fontSize: 11,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}
