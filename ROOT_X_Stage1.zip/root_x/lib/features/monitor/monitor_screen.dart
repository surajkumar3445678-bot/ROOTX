import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/platform/system_channel.dart';
import '../../core/providers.dart';
import '../../core/utils/format.dart';
import '../../core/widgets/app_card.dart';

class MonitorScreen extends ConsumerWidget {
  const MonitorScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final async = ref.watch(liveDeviceInfoProvider);
    final d = async.asData?.value;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
      children: [
        Text('Monitor',
            style: theme.textTheme.headlineSmall
                ?.copyWith(fontWeight: FontWeight.w700)),
        const SizedBox(height: 4),
        Text('Live values read from Android, refreshed every 3 seconds.',
            style: theme.textTheme.bodyMedium),
        const SizedBox(height: 16),
        if (d == null && async.isLoading)
          const Center(child: CircularProgressIndicator())
        else if (d == null)
          const AppCard(
            child: Text(
              'Native device data is unavailable. Run the app on an Android '
              'device.',
            ),
          )
        else ...[
          _Meter(
            title: 'RAM',
            fraction: d.ramUsedFraction,
            text:
                '${formatBytes(d.ramTotal - d.ramAvail)} used of ${formatBytes(d.ramTotal)}',
          ),
          const SizedBox(height: 10),
          _Meter(
            title: 'Storage (internal)',
            fraction: d.storageUsedFraction,
            text:
                '${formatBytes(d.storageTotal - d.storageFree)} used of ${formatBytes(d.storageTotal)}',
          ),
          const SizedBox(height: 10),
          _Meter(
            title: 'Battery',
            fraction: d.batteryPct < 0 ? 0 : d.batteryPct / 100,
            text: d.batteryPct < 0
                ? 'Unavailable'
                : '${d.batteryPct}%${d.charging ? ' · charging' : ''}'
                    '${d.batteryTempC != null ? ' · ${d.batteryTempC!.toStringAsFixed(1)} °C' : ''}',
          ),
          const SizedBox(height: 10),
          _Details(d: d),
          const SizedBox(height: 10),
          Text(
            'CPU frequency, GPU info and device temperatures arrive in '
            'Stage 4. They are not shown because they are not read yet.',
            style: theme.textTheme.bodySmall,
          ),
        ],
      ],
    );
  }
}

class _Meter extends StatelessWidget {
  const _Meter({
    required this.title,
    required this.fraction,
    required this.text,
  });

  final String title;
  final double fraction;
  final String text;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: theme.textTheme.titleSmall),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: fraction.clamp(0.0, 1.0),
              minHeight: 8,
            ),
          ),
          const SizedBox(height: 8),
          Text(text, style: theme.textTheme.bodySmall),
        ],
      ),
    );
  }
}

class _Details extends StatelessWidget {
  const _Details({required this.d});

  final DeviceInfo d;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final rows = <MapEntry<String, String>>[
      MapEntry('Manufacturer', d.manufacturer),
      MapEntry('Model', d.model),
      MapEntry('Android', '${d.androidVersion} (API ${d.sdkInt})'),
      MapEntry('Build', d.buildNumber),
      MapEntry('Hardware', d.hardware),
      MapEntry('Primary ABI', d.abi),
      MapEntry('CPU cores', '${d.cores}'),
      MapEntry('Display', '${d.screenWidth} × ${d.screenHeight}'),
      MapEntry('Refresh rate', '${d.refreshRate.toStringAsFixed(0)} Hz'),
      MapEntry('su binary', d.suBinaryFound ? 'Found' : 'Not found'),
    ];
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Device details', style: theme.textTheme.titleSmall),
          const SizedBox(height: 8),
          for (final r in rows)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    width: 110,
                    child: Text(r.key, style: theme.textTheme.bodySmall),
                  ),
                  Expanded(
                    child: Text(r.value, style: theme.textTheme.bodyMedium),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}
