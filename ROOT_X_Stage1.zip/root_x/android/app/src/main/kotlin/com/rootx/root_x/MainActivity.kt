package com.rootx.root_x

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File

class MainActivity : FlutterActivity() {

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "rootx/system")
            .setMethodCallHandler { call, result ->
                try {
                    when (call.method) {
                        "getDeviceInfo" -> result.success(deviceInfo())
                        "getLaunchableApps" -> result.success(launchableApps())
                        else -> result.notImplemented()
                    }
                } catch (e: Exception) {
                    result.error("NATIVE_ERROR", e.message, null)
                }
            }
    }

    private fun deviceInfo(): Map<String, Any?> {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)

        val stat = StatFs(Environment.getDataDirectory().path)

        val bat = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = bat?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = bat?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val rawTemp = bat?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: Int.MIN_VALUE
        val status = bat?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        val dm = resources.displayMetrics
        @Suppress("DEPRECATION")
        val refresh = windowManager.defaultDisplay.refreshRate.toDouble()

        // Only checks whether a su binary exists. It does NOT prove root access is granted.
        val suPaths = listOf(
            "/system/bin/su", "/system/xbin/su", "/sbin/su", "/su/bin/su",
            "/system/sbin/su", "/vendor/bin/su", "/data/local/xbin/su", "/data/local/bin/su"
        )
        val suFound = suPaths.any { File(it).exists() }

        return mapOf(
            "androidVersion" to Build.VERSION.RELEASE,
            "sdkInt" to Build.VERSION.SDK_INT,
            "manufacturer" to Build.MANUFACTURER,
            "model" to Build.MODEL,
            "buildNumber" to Build.DISPLAY,
            "hardware" to Build.HARDWARE,
            "abi" to (Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown"),
            "cores" to Runtime.getRuntime().availableProcessors(),
            "ramTotal" to mi.totalMem,
            "ramAvail" to mi.availMem,
            "storageTotal" to stat.totalBytes,
            "storageFree" to stat.availableBytes,
            "batteryPct" to pct,
            "batteryTempC" to (if (rawTemp == Int.MIN_VALUE) null else rawTemp / 10.0),
            "charging" to charging,
            "suBinaryFound" to suFound,
            "screenWidth" to dm.widthPixels,
            "screenHeight" to dm.heightPixels,
            "refreshRate" to refresh
        )
    }

    private fun launchableApps(): List<Map<String, Any?>> {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .map { ri ->
                val pkg = ri.activityInfo.packageName
                val version = try {
                    pm.getPackageInfo(pkg, 0).versionName ?: ""
                } catch (e: Exception) {
                    ""
                }
                val isSystem =
                    (ri.activityInfo.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                mapOf<String, Any?>(
                    "name" to ri.loadLabel(pm).toString(),
                    "package" to pkg,
                    "version" to version,
                    "system" to isSystem
                )
            }
            .distinctBy { it["package"] as String }
            .sortedBy { (it["name"] as String).lowercase() }
    }
}
