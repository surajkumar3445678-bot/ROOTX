import 'package:flutter/material.dart';

import '../../core/modules.dart';
import '../../core/widgets/status_chip.dart';

class ModuleSearchDelegate extends SearchDelegate<ToolModule?> {
  ModuleSearchDelegate() : super(searchFieldLabel: 'Search tools and modules');

  @override
  List<Widget>? buildActions(BuildContext context) => [
        if (query.isNotEmpty)
          IconButton(
            icon: const Icon(Icons.clear),
            onPressed: () => query = '',
          ),
      ];

  @override
  Widget? buildLeading(BuildContext context) => IconButton(
        icon: const Icon(Icons.arrow_back),
        onPressed: () => close(context, null),
      );

  @override
  Widget buildResults(BuildContext context) => _list(context);

  @override
  Widget buildSuggestions(BuildContext context) => _list(context);

  Widget _list(BuildContext context) {
    final q = query.trim().toLowerCase();
    final results = toolModules
        .where((m) =>
            m.title.toLowerCase().contains(q) ||
            m.subtitle.toLowerCase().contains(q))
        .toList();
    if (results.isEmpty) {
      return const Center(child: Text('No modules match your search'));
    }
    return ListView(
      children: [
        for (final m in results)
          ListTile(
            leading: Icon(m.icon),
            title: Text(m.title),
            subtitle: Text(m.subtitle),
            trailing: StatusChip(status: m.status),
            onTap: () => close(context, m),
          ),
      ],
    );
  }
}
