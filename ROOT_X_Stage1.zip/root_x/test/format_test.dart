import 'package:flutter_test/flutter_test.dart';
import 'package:root_x/core/utils/format.dart';

void main() {
  test('formatBytes formats common sizes', () {
    expect(formatBytes(0), '0 B');
    expect(formatBytes(1024), '1.0 KB');
    expect(formatBytes(1536 * 1024 * 1024), '1.5 GB');
  });

  test('formatBytes handles invalid input', () {
    expect(formatBytes(-1), '—');
  });
}
