import 'package:flutter/material.dart';

import '../theme/app_colors.dart';

/// ROOT X logo drawn in code (matches assets/logo/root_x.svg).
class RootXLogo extends StatelessWidget {
  const RootXLogo({super.key, this.size = 44});

  final double size;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(painter: _LogoPainter()),
    );
  }
}

class _LogoPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size s) {
    final rect = Offset.zero & s;
    final rrect = RRect.fromRectAndRadius(rect, Radius.circular(s.width * 0.24));
    canvas.drawRRect(rrect, Paint()..color = const Color(0xFF0A0A0F));

    final rim = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = s.width * 0.03
      ..shader = const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [AppColors.purple, AppColors.cyan],
      ).createShader(rect);
    canvas.drawRRect(rrect.deflate(s.width * 0.015), rim);

    Paint stroke(Color c) => Paint()
      ..color = c
      ..style = PaintingStyle.stroke
      ..strokeWidth = s.width * 0.14
      ..strokeCap = StrokeCap.round;

    final a = s.width * 0.30;
    final b = s.width * 0.70;
    canvas.drawLine(Offset(a, a), Offset(b, b), stroke(AppColors.purple));
    canvas.drawLine(Offset(b, a), Offset(a, b), stroke(AppColors.cyan));
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
