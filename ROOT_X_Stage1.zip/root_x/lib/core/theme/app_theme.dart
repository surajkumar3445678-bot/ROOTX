import 'package:flutter/material.dart';

import 'app_colors.dart';

class AppTheme {
  static ThemeData build(Color accent, Brightness brightness) {
    final dark = brightness == Brightness.dark;
    final scheme = ColorScheme.fromSeed(
      seedColor: accent,
      brightness: brightness,
    ).copyWith(
      primary: accent,
      secondary: AppColors.cyan,
      surface: dark ? AppColors.graphite : Colors.white,
    );
    return ThemeData(
      useMaterial3: true,
      brightness: brightness,
      colorScheme: scheme,
      scaffoldBackgroundColor:
          dark ? AppColors.black : const Color(0xFFF4F4F8),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: dark ? AppColors.graphite : Colors.white,
        indicatorColor: accent.withAlpha(64),
      ),
    );
  }
}
