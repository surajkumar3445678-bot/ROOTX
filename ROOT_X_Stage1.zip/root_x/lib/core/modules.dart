import 'package:flutter/material.dart';

enum ModuleStatus { ready, partial, planned }

extension ModuleStatusX on ModuleStatus {
  String get label => switch (this) {
        ModuleStatus.ready => 'Ready',
        ModuleStatus.partial => 'Partial',
        ModuleStatus.planned => 'Planned',
      };
}

class ToolModule {
  const ToolModule({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.stage,
    required this.status,
    this.tabIndex,
  });

  final String id;
  final String title;
  final String subtitle;
  final IconData icon;

  /// Development stage (1-8) in which the module is delivered.
  final int stage;
  final ModuleStatus status;

  /// If set, opening the module jumps to this bottom-navigation tab.
  final int? tabIndex;
}

const List<ToolModule> toolModules = [
  ToolModule(
    id: 'file_manager',
    title: 'File Manager',
    subtitle: 'Browse, copy, move, search files',
    icon: Icons.folder_rounded,
    stage: 2,
    status: ModuleStatus.planned,
  ),
  ToolModule(
    id: 'apk_studio',
    title: 'APK Studio',
    subtitle: 'Inspect APK, manifest, signatures',
    icon: Icons.android_rounded,
    stage: 2,
    status: ModuleStatus.planned,
  ),
  ToolModule(
    id: 'app_resources',
    title: 'App Resources',
    subtitle: 'Edit assets of your own projects',
    icon: Icons.inventory_2_rounded,
    stage: 2,
    status: ModuleStatus.planned,
  ),
  ToolModule(
    id: 'batch_tools',
    title: 'Batch Tools',
    subtitle: 'Batch rename, copy, hash',
    icon: Icons.library_add_check_rounded,
    stage: 2,
    status: ModuleStatus.planned,
  ),
  ToolModule(
    id: 'permission_manager',
    title: 'Permission Manager',
    subtitle: 'Audit permissions and special access',
    icon: Icons.shield_rounded,
    stage: 3,
    status: ModuleStatus.planned,
  ),
  ToolModule(
    id: 'root_manager',
    title: 'Root Manager',
    subtitle: 'Root, Shizuku and ADB status',
    icon: Icons.admin_panel_settings_rounded,
    stage: 4,
    status: ModuleStatus.planned,
  ),
  ToolModule(
    id: 'system_monitor',
    title: 'System Monitor',
    subtitle: 'Live RAM, storage, battery, device info',
    icon: Icons.monitor_heart_rounded,
    stage: 4,
    status: ModuleStatus.partial,
    tabIndex: 3,
  ),
  ToolModule(
    id: 'gaming_toolkit',
    title: 'Gaming Toolkit',
    subtitle: 'Touch tester, latency, game profiles',
    icon: Icons.sports_esports_rounded,
    stage: 5,
    status: ModuleStatus.planned,
  ),
  ToolModule(
    id: 'developer_tools',
    title: 'Developer Tools',
    subtitle: 'Terminal, logcat, viewers, scripts',
    icon: Icons.terminal_rounded,
    stage: 5,
    status: ModuleStatus.planned,
  ),
  ToolModule(
    id: 'crash_analyzer',
    title: 'Crash Analyzer',
    subtitle: 'Logs, stack traces, reports',
    icon: Icons.bug_report_rounded,
    stage: 5,
    status: ModuleStatus.planned,
  ),
  ToolModule(
    id: 'backup_security',
    title: 'Backup & Security',
    subtitle: 'Backups, hashes, integrity checks',
    icon: Icons.backup_rounded,
    stage: 6,
    status: ModuleStatus.planned,
  ),
  ToolModule(
    id: 'automation',
    title: 'Automation',
    subtitle: 'Scheduled local tasks and rules',
    icon: Icons.auto_mode_rounded,
    stage: 6,
    status: ModuleStatus.planned,
  ),
  ToolModule(
    id: 'plugin_manager',
    title: 'Plugin Manager',
    subtitle: 'Sandboxed plugins',
    icon: Icons.extension_rounded,
    stage: 7,
    status: ModuleStatus.planned,
  ),
  ToolModule(
    id: 'floating_toolbox',
    title: 'Floating Toolbox',
    subtitle: 'Draggable overlay shortcuts',
    icon: Icons.bubble_chart_rounded,
    stage: 7,
    status: ModuleStatus.planned,
  ),
  ToolModule(
    id: 'web_server',
    title: 'Local Web Server',
    subtitle: 'Password-protected LAN file sharing',
    icon: Icons.wifi_tethering_rounded,
    stage: 7,
    status: ModuleStatus.planned,
  ),
  ToolModule(
    id: 'theme_engine',
    title: 'Theme Engine',
    subtitle: 'Theme mode and accent colors',
    icon: Icons.palette_rounded,
    stage: 8,
    status: ModuleStatus.partial,
    tabIndex: 4,
  ),
];

/// Modules shown in the dashboard grid, in order.
const List<String> dashboardModuleIds = [
  'file_manager',
  'apk_studio',
  'permission_manager',
  'root_manager',
  'system_monitor',
  'gaming_toolkit',
  'developer_tools',
  'backup_security',
  'plugin_manager',
  'automation',
];

List<ToolModule> get dashboardModules => [
      for (final id in dashboardModuleIds)
        toolModules.firstWhere((m) => m.id == id),
    ];
