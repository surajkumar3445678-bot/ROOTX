/// Formats a byte count as a human readable string (1024 based).
String formatBytes(num bytes, {int decimals = 1}) {
  if (bytes < 0) return '—';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  var value = bytes.toDouble();
  var i = 0;
  while (value >= 1024 && i < units.length - 1) {
    value /= 1024;
    i++;
  }
  return '${value.toStringAsFixed(i == 0 ? 0 : decimals)} ${units[i]}';
}
