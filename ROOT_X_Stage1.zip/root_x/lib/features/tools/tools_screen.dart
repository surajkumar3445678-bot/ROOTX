import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/modules.dart';
import '../../core/widgets/app_card.dart';
import '../../core/widgets/status_chip.dart';
import 'module_actions.dart';

class ToolsScreen extends ConsumerWidget {
  const ToolsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
      children: [
        Text('Tools',
            style: theme.textTheme.headlineSmall
                ?.copyWith(fontWeight: FontWeight.w700)),
        const SizedBox(height: 4),
        Text(
          'Every module with its real implementation status.',
          style: theme.textTheme.bodyMedium,
        ),
        const SizedBox(height: 16),
        for (final m in toolModules) ...[
          AppCard(
            onTap: () => openModule(context, ref, m),
            child: Row(
              children: [
                Icon(m.icon, color: theme.colorScheme.primary),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(m.title, style: theme.textTheme.titleSmall),
                      Text(
                        '${m.subtitle} · Stage ${m.stage}',
                        style: theme.textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
                StatusChip(status: m.status),
              ],
            ),
          ),
          const SizedBox(height: 10),
        ],
      ],
    );
  }
}
