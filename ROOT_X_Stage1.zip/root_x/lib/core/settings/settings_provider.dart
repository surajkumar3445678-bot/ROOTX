import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../theme/app_colors.dart';

class SettingsState {
  const SettingsState({
    this.themeMode = ThemeMode.dark,
    this.accentIndex = 0,
  });

  final ThemeMode themeMode;
  final int accentIndex;

  Color get accent => AppColors.accents[accentIndex].color;

  SettingsState copyWith({ThemeMode? themeMode, int? accentIndex}) =>
      SettingsState(
        themeMode: themeMode ?? this.themeMode,
        accentIndex: accentIndex ?? this.accentIndex,
      );
}

class SettingsNotifier extends Notifier<SettingsState> {
  static const _kMode = 'theme_mode';
  static const _kAccent = 'accent';

  @override
  SettingsState build() {
    _load();
    return const SettingsState();
  }

  Future<void> _load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final mode = prefs.getInt(_kMode);
      final accent = prefs.getInt(_kAccent);
      state = SettingsState(
        themeMode: (mode != null && mode >= 0 && mode < ThemeMode.values.length)
            ? ThemeMode.values[mode]
            : ThemeMode.dark,
        accentIndex:
            (accent != null && accent >= 0 && accent < AppColors.accents.length)
                ? accent
                : 0,
      );
    } catch (_) {
      // Keep defaults if preferences are unavailable.
    }
  }

  Future<void> setThemeMode(ThemeMode mode) async {
    state = state.copyWith(themeMode: mode);
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(_kMode, mode.index);
    } catch (_) {}
  }

  Future<void> setAccent(int index) async {
    state = state.copyWith(accentIndex: index);
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(_kAccent, index);
    } catch (_) {}
  }
}

final settingsProvider =
    NotifierProvider<SettingsNotifier, SettingsState>(SettingsNotifier.new);
