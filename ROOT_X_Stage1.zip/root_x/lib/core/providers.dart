import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'platform/system_channel.dart';

final systemChannelProvider = Provider<SystemChannel>(
  (ref) => const SystemChannel(),
);

/// Re-reads real device info every 3 seconds while something is listening.
final liveDeviceInfoProvider = StreamProvider.autoDispose<DeviceInfo?>(
  (ref) async* {
    final channel = ref.watch(systemChannelProvider);
    while (true) {
      yield await channel.deviceInfo();
      await Future<void>.delayed(const Duration(seconds: 3));
    }
  },
);

final appsProvider = FutureProvider.autoDispose<List<AppEntry>>(
  (ref) => ref.watch(systemChannelProvider).launchableApps(),
);

/// Selected bottom navigation tab (0 Home, 1 Tools, 2 Apps, 3 Monitor, 4 Settings).
final navIndexProvider = StateProvider<int>((ref) => 0);
