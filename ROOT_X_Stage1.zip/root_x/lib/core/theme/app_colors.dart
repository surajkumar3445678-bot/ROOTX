import 'package:flutter/material.dart';

class AccentOption {
  const AccentOption(this.name, this.color);
  final String name;
  final Color color;
}

class AppColors {
  static const Color purple = Color(0xFF8B2BFF);
  static const Color cyan = Color(0xFF00E5FF);
  static const Color black = Color(0xFF050507);
  static const Color graphite = Color(0xFF14141A);

  static const List<AccentOption> accents = [
    AccentOption('Electric Purple', purple),
    AccentOption('Neon Cyan', cyan),
    AccentOption('Crimson', Color(0xFFFF2D55)),
    AccentOption('Emerald', Color(0xFF00D68F)),
    AccentOption('Amber', Color(0xFFFFB300)),
  ];
}
