import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/modules.dart';
import '../../core/platform/system_channel.dart';
import '../../core/providers.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/format.dart';
import '../../core/widgets/app_card.dart';
import '../../core/widgets/root_x_logo.dart';
import '../../core/widgets/stat_card.dart';
import '../../core/widgets/status_chip.dart';
import '../tools/module_actions.dart';
import '../tools/module_search.dart';

class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final d = ref.watch(liveDeviceInfoProvider).asData?.value;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      children: [
        _Header(
          onNotifications: () => _showNotifications(context),
          onSettings: () => ref.read(navIndexProvider.notifier).state = 4,
        ),
        const SizedBox(height: 16),
        InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () async {
            final picked = await showSearch<ToolModule?>(
              context: context,
              delegate: ModuleSearchDelegate(),
            );
            if (picked != null && context.mounted) {
              openModule(context, ref, picked);
            }
          },
          child: Ink(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              color: theme.colorScheme.surface,
              border: Border.all(
                color: theme.brightness == Brightness.dark
                    ? Colors.white12
                    : Colors.black12,
              ),
            ),
            child: Row(
              children: [
                const Icon(Icons.search_rounded),
                const SizedBox(width: 10),
                Text('Search tools and modules',
                    style: theme.textTheme.bodyMedium),
              ],
            ),
          ),
        ),
        const SizedBox(height: 20),
        Text('Device overview', style: theme.textTheme.titleMedium),
        const SizedBox(height: 10),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          childAspectRatio: 1.3,
          children: _overviewCards(d),
        ),
        if (d == null) ...[
          const SizedBox(height: 8),
          Text(
            'Device data is read from Android. It is unavailable until the '
            'native layer responds (run on an Android device).',
            style: theme.textTheme.bodySmall,
          ),
        ],
        const SizedBox(height: 20),
        Text('Modules', style: theme.textTheme.titleMedium),
        const SizedBox(height: 10),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          childAspectRatio: 1.25,
          children: [
            for (final m in dashboardModules)
              AppCard(
                onTap: () => openModule(context, ref, m),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Icon(m.icon, size: 28, color: theme.colorScheme.primary),
                    Text(
                      m.title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: theme.textTheme.titleSmall,
                    ),
                    StatusChip(status: m.status),
                  ],
                ),
              ),
          ],
        ),
      ],
    );
  }

  List<Widget> _overviewCards(DeviceInfo? d) {
    String v(String Function(DeviceInfo) f) => d == null ? '—' : f(d);
    return [
      StatCard(
        icon: Icons.admin_panel_settings_rounded,
        title: 'Root',
        value: v((x) => x.suBinaryFound ? 'su found' : 'Not detected'),
        subtitle: 'Access not verified yet',
      ),
      StatCard(
        icon: Icons.android_rounded,
        title: 'Android',
        value: v((x) => x.androidVersion),
        subtitle: v((x) => 'API ${x.sdkInt} · ${x.model}'),
      ),
      StatCard(
        icon: Icons.memory_rounded,
        title: 'CPU',
        value: v((x) => '${x.cores} cores'),
        subtitle: v((x) => x.abi),
      ),
      StatCard(
        icon: Icons.developer_board_rounded,
        title: 'RAM',
        value: v((x) => '${(x.ramUsedFraction * 100).round()}%'),
        subtitle: v((x) =>
            '${formatBytes(x.ramTotal - x.ramAvail)} / ${formatBytes(x.ramTotal)}'),
        progress: d?.ramUsedFraction,
      ),
      StatCard(
        icon: Icons.sd_storage_rounded,
        title: 'Storage',
        value: v((x) => '${(x.storageUsedFraction * 100).round()}%'),
        subtitle: v((x) =>
            '${formatBytes(x.storageTotal - x.storageFree)} / ${formatBytes(x.storageTotal)}'),
        progress: d?.storageUsedFraction,
      ),
      StatCard(
        icon: Icons.battery_charging_full_rounded,
        title: 'Battery',
        value: v((x) => x.batteryPct < 0 ? '—' : '${x.batteryPct}%'),
        subtitle: v((x) => x.charging ? 'Charging' : 'On battery'),
        progress: (d != null && d.batteryPct >= 0) ? d.batteryPct / 100 : null,
      ),
    ];
  }

  void _showNotifications(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (_) => const Padding(
        padding: EdgeInsets.fromLTRB(20, 0, 20, 32),
        child: Text('No notifications.'),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header({required this.onNotifications, required this.onSettings});

  final VoidCallback onNotifications;
  final VoidCallback onSettings;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Row(
      children: [
        const RootXLogo(size: 44),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'ROOT X',
                style: theme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w800,
                  letterSpacing: 2,
                ),
              ),
              Text(
                'ULTIMATE PRO',
                style: theme.textTheme.labelSmall?.copyWith(
                  color: AppColors.cyan,
                  letterSpacing: 3,
                ),
              ),
            ],
          ),
        ),
        IconButton(
          onPressed: onNotifications,
          icon: const Icon(Icons.notifications_none_rounded),
          tooltip: 'Notifications',
        ),
        IconButton(
          onPressed: onSettings,
          icon: const Icon(Icons.settings_outlined),
          tooltip: 'Settings',
        ),
      ],
    );
  }
}
